pmssm-al-benchmark tutorial data sample
=======================================
Written 2026-10-23 by scripts/tutorial/make_tutorial_sample.py
(repository commit d89fd86, seed 20261023).

pool/ntuple.tutorial.0.root   50000 rows drawn uniformly from the first
                              40 files (400000 rows) of the relic-density
                              pool /ptmp/jwuerzin/data/18387358
mcmc/ntuple.tutorial.0.root   100000 rows drawn uniformly over the whole
                              emcee reference /ptmp/jwuerzin/data/neutralino_v4 (35261440 rows; walker repeats kept,
                              they are the posterior weights)

Both hold the `susy` tree with the 19 input parameters (IN_*), MO_Omega, SP_m_h,
SP_LSP_type, the LSP composition fractions and MO_cdm_is_neutralino where the
source carries it. They exist for doc/TUTORIAL.md and are far too small for
any physics conclusion.
